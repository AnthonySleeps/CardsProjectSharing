/*@author Anthony Amedome
 * Mrs. Terri Kelly
 * Class depicts a card
 * 
 */

public class Card implements Comparable<Card>{
	private int number;
	private String suit;
	private int value;
	private String game;
	
	/*@param n is an int for number of the card
	 * @param s is a  String for suit of card
	 * considers value the same as number because no specified game rule
	 */
	public Card(int n, String s) {
		number = n;
		suit = s;
		value = n;
		game = "None";
	}
	
	/*@param n for number
	 * @param s for suit
	 * @param g for game rule
	 * has a switch statement to switch value of cards depending on game rule
	 */
	public Card(int n, String s, String g) {
		number = n;
		suit = s;
		switch (g) {
			case "Spades":
				if (n==1) {
					value = 14;
				}
				if (s.equals("Spades")){
					value += n+15;
				} else {
					value += n;
				}
			break;
			case "Tablic":
				value = n;
			break;
			case "Blackjack":
				if (n >= 10 ) {
					value = 10;
				} else {
					value = n;
				}
			case "None":
				value = n;
			break;
		}
	}
	
	/*@return number of card
	 */
	public int getNumber() {
		return this.number;
	}

	/*@return suit of card
	 */
	public String getSuit() {
		return this.suit;
	}

	/*@return game rule of card
	 */
	public String getGame() {
		return this.game;
	}
	
	/*@return value of card
	 */
	public int getValue() {
		return this.value;
	}
	
	/*@param n int for number of Card
	 * allows the changing of number from outside the class (unneeded)
	 */
	public void setNumber(int n) {
		this.number = n;
	}

	/*@param s String for suit of card
	 * allows the changing of suit from outside the class (unneeded)
	 */
	public void setSuit(String s) {
		this.suit = s;
	}
	
	/*@param o other card object
	 *  determines whether the value of this card and another card are equal
	 */
	@Override
	public boolean equals(Object o) {
		while (o instanceof Card) {
			Card c = (Card)o;
			if (this.compareTo(c) == 0) {
				return true;
			}
			return false;
		}
		System.out.println("*Warning* Parameter is not of type card");
		return false;
	}
	
	//did not work when I put @ Override
	public int compare(Card c, Card c1) {
		if (c.value == c1.value && c.suit.equals(c1.suit)) {
			return 0;
		} else if (c.value > c1.value) {
			return 1;
		}
		return -1;
	}
	
	/*@param c for other card object
	 * this method compares cards based on their value
	 */
	@Override
	public int compareTo(Card c) {
		if (this.value == c.value && this.suit.equals(c.suit)) {
			return 0;
		} else if (this.value > c.value) {
			return 1;
		}
		return -1;
	}
	
	/*@return String that print out number and suit of card
	 * simple toString method
	 */
	@Override
	public String toString() {
		return (this.getNumber() + " of " + this.suit);
	}
	
}
