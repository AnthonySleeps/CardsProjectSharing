/* Anthony Amedome
 * 
 */

import java.util.Random;

public class Deck implements Comparable<Deck>{
	
	private Random rand = new Random();
	private final int TOTAL = 52;
	private Card[] deck = new Card[TOTAL];
	private String game;
	private Card topCard = deck[deck.length -1];
	
	/*@param string g for game values of all cards
	 * constructs a deck full of 52 random cards
	 */
	public Deck (String g) {		
		game = g;
		for (int i = 0; i <= 12; i++) {
			deck[i] = new Card(i+1,"Spades",g);
		}
		for (int i = 13; i <= 25; i++) {
			deck[i] = new Card(i-12,"Hearts",g);
		}
		for (int i = 26; i <= 38; i++) {
			deck[i] = new Card(i-25,"Clubs",g);
		}
		for (int i = 39; i <= 51; i++) {
			deck[i] = new Card(i-38,"Diamonds",g);
		}
	}
	
	/*constructor that sets game to None as default
	 * 
	 */
	public Deck() {
		this("None");
	}
	
	/*@return total number of cards in a deck
	 * 
	 */
	public int getTOTAL () {
		return this.TOTAL;
	}
	
	/*@return card array that is the deck
	 * 
	 */
	public Card[] getDeck() {
		return deck;
	}
	
	/*@return the card that is the last in the array
	 * 
	 */
	public Card getTopCard() {
		return this.topCard;
	}
	
	/*@return the string that indicates the game rule
	 * 
	 */
	public String getGame() {
		return this.game;
	}
	
	/*@param string that allows you to change the game rule
	 * 
	 */
	public void setGame(String g) {
		this.game = g;
	}
	
	/*@param card that allows you the change the last card in deck
	 * 
	 */
	public void setTopCard(Card c) {
		this.topCard = c;
	}
	
	/*@return String of all cards in deck
	 * toString that loops and uses toString of card
	 */
	@Override
	public String toString() {
		String output = "";
		for (int i = 0; i < TOTAL -1; i ++) {
			output += deck[i].toString();
			output += ", ";
		}
		return output;
	}
	
	/*@param other Deck that can be compared to this deck
	 * only returns 0 if they have same numbers and same suits in order
	 */
	@Override
	public int compareTo (Deck other) {
		int checks = 0;
		for (int i = 0; i < other.TOTAL -1; i++) {
			if (other.deck[i].compareTo(this.deck[i]) == 1) {
				checks++;
			} else if (other.deck[i].compareTo(this.deck[i]) == -1) {
				checks--;
			}
		}
		
		if (checks == 0) {
			return 0;
		} else if (checks >= 1){
			return 1;
		} else {
			return -1;
		}
	}
	
	/*@param other Object that is casted into Deck if it is an instance of it
	 * only returns true if they have same numbers and same suits in order
	 */
	@Override
	public boolean equals(Object other) {
		while (other instanceof Deck) {
			Deck d = (Deck)other;
			if (this.compareTo(d) == 0) {
				return true;
			} else {
				return false;
			}
		}
		
		System.out.println("*Warning* parameter is not of type Deck");
		return false;
		
	}
	
	public Card[][] deal (int n) {

		if (TOTAL%n == 0) {
			Card[][] hands = new Card[n][TOTAL/n];
			for (int i = 0; i > n; i++)  {
				for (int x = 0; x > TOTAL/n; x++) {
					hands[i][x] = deck[x];
				}
			}
			
			return hands;
		}
		return null;
	}
	
	/*@return the card at the last value of deck
	 * 
	 */
	public Card draw() {

		return topCard;
	}

	/*selection sort method
	 * sorts the cards in deck with their compare to method 
	 */
	public void selectionSort() {

		for (int x = 0; x < TOTAL -1; x++) {
			Card minimum = deck[x];
			int temp = x;
			for (int i = x+1; i < TOTAL; i++) {
				if (deck[i].compareTo(minimum) < 0 ) {
					minimum = deck[i];
					temp = i;	
				}
			}
			
			deck[temp] = deck[x];
			deck[x] = minimum;
		}
	}
	
	/*mergeSort method
	 * sorts the cards in deck with their compareTo method
	 */
	public Card[] mergeSort (Card[] c) {
		if (c.length == 2) {
			if (c[0].compareTo(c[1]) < 1) {
				Card temp = c[0];
				c[0] = c[1];
				c[1] = temp;
			}
		}
		
		if (c.length <= 1) {
			return c;
		}
		
		int mid = c.length/2;
		Card[] leftArr = new Card[mid];
		Card[] rightArr = new Card[c.length - mid];
		
		for (int i = 0; i < mid; i++) {
			leftArr[i] = c[i];
		}
		for (int i = mid; i < c.length; i++) {
			rightArr[i-mid] = c[i];
		}	
		
		mergeSort(leftArr);
		mergeSort(rightArr);
		return merge(c, leftArr,rightArr);
		
	}
	
	/*@param c array that represents the full deck
	 * @param left array that represents the halved array that have gone through mergeSort
	 * @param right array that represents the other halved array
	 * merge method that is a tool for mergeSort final step
	 */
	public Card[] merge(Card[] c, Card[] leftArr, Card[] rightArr) {
	    int i = 0, j = 0, k = 0;

	    while (i < leftArr.length && j < rightArr.length) {
	        if (leftArr[i].compareTo(rightArr[j]) <= 0) {
	            c[k++] = leftArr[i++];
	        } else {
	            c[k++] = rightArr[j++];
	        }
	    }

	    while (i < leftArr.length) {
	        c[k++] = leftArr[i++];
	    }

	    while (j < rightArr.length) {
	        c[k++] = rightArr[j++];
	    }
	    
	    return c;
	}
	
	/*bubble sort method
	 * Order is n^2 (same as selection sort)
	 */
	public void bubbleSort() {
	    for (int i = 0; i < TOTAL - 1; i++) {
	        for (int j = 0; j < TOTAL - 1 - i; j++) {
	            if (deck[j].compareTo(deck[j + 1]) > 0) {
	                Card temp = deck[j];
	                deck[j] = deck[j + 1];
	                deck[j + 1] = temp;
	            }
	        }
	    }
	}
	
	/*randomly switches the index of 2 cards in a deck
	 * I looked up how many times a card had to be switched on average to have a shuffled deck and got 236
	 */
	public void shuffle() {
		for (int i = 0; i < 236; i++) {
			int temp = rand.nextInt(51);
			int temp1 = rand.nextInt(51);
			Card tempCard = deck[temp];
			Card tempCard1 = deck[temp1];
			deck[temp] = tempCard1;
			deck[temp1] = tempCard;
			
		}
	}
	
	/*@return a random card from the deck
	 * 
	 */
	public Card pick() {
		return deck[rand.nextInt(51)];
	}
	
	
	
}
