
public class Test {

	public static void main(String[] args) {
		System.out.println(new Card(1,"Spades","Spades").getValue());
		Deck deck1 = new Deck();
		System.out.println("Deck 1 original: " + deck1);
		deck1.shuffle();
		System.out.println("Deck 1 after first shuffle: " +  deck1);
		deck1.selectionSort();
		System.out.println("Deck 1 after selection sort: " + deck1);
		deck1.shuffle();
		System.out.println("Deck 1 after second shuffle: " + deck1);
		deck1.mergeSort(deck1.getDeck());
		System.out.println("Deck 1 after mergeSort: " + deck1);
		deck1.shuffle();
		deck1.bubbleSort();
		System.out.println("Deck 1 after bubble sort:" + deck1);
		Deck deck2 = new Deck("Spades");
		Deck deck3 = new Deck("Spades");
		System.out.println("Deck two original: " + deck2);
		System.out.println("Deck three original: " + deck3);
		System.out.println("Deck 2 and 3 original comparison: " + deck2.compareTo(deck3));
		deck2.mergeSort(deck2.getDeck());
		System.out.println("Deck 2 after sorting with spades rules: " + deck2);
		System.out.println("Deck 2 and 3 comparison after deck 2 shuffle:" + deck2.compareTo(deck3));
		System.out.println("Deck 3 and 2 comparison after deck 2 shuffle: " + deck3.compareTo(deck2));
	}

}
